package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US026Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US026_createHabit_success() {
        habitTracker.createHabit("Drink Water", "Health", "Daily");
        assertTrue(habitTracker.getHabit("Drink Water") != null);
    }

    @Test
    public void US026_createHabit_duplicateName_fails() {
        habitTracker.createHabit("Drink Water", "Health", "Daily");
        assertThrows(IllegalArgumentException.class, () -> habitTracker.createHabit("Drink Water", "Health", "Daily"));
    }

    @Test
    public void US026_createHabit_emptyName_fails() {
        assertThrows(IllegalArgumentException.class, () -> habitTracker.createHabit("", "Health", "Daily"));
    }

    @Test
    public void US026_editHabit_success() {
        habitTracker.createHabit("Drink Water", "Health", "Daily");
        habitTracker.editHabit("Drink Water", "Drink Water Daily", "Health", "Daily");
        assertEquals("Drink Water Daily", habitTracker.getHabit("Drink Water").getDescription());
    }

    @Test
    public void US026_editHabit_nonExistentHabit_fails() {
        assertThrows(IllegalArgumentException.class, () -> habitTracker.editHabit("NonExistentHabit", "New Description", "Health", "Daily"));
    }

    @Test
    public void US026_deleteHabit_success() {
        habitTracker.createHabit("Drink Water", "Health", "Daily");
        habitTracker.deleteHabit("Drink Water");
        assertNull(habitTracker.getHabit("Drink Water"));
    }

    @Test
    public void US026_deleteHabit_nonExistentHabit_fails() {
        assertThrows(IllegalArgumentException.class, () -> habitTracker.deleteHabit("NonExistentHabit"));
    }

    @Test
    public void US026_markHabitCompleted_success() {
        habitTracker.createHabit("Drink Water", "Health", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        assertTrue(habitTracker.getHabit("Drink Water").isCompletedToday());
    }

    @Test
    public void US026_markHabitCompleted_twice_fails() {
        habitTracker.createHabit("Drink Water", "Health", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        assertThrows(IllegalStateException.class, () -> habitTracker.markHabitCompleted("Drink Water"));
    }

    @Test
    public void US026_undoHabitCompletion_success() {
        habitTracker.createHabit("Drink Water", "Health", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        habitTracker.undoHabitCompletion("Drink Water");
        assertFalse(habitTracker.getHabit("Drink Water").isCompletedToday());
    }

    @Test
    public void US026_undoHabitCompletion_notCompletedToday_fails() {
        habitTracker.createHabit("Drink Water", "Health", "Daily");
        assertThrows(IllegalStateException.class, () -> habitTracker.undoHabitCompletion("Drink Water"));
    }

}
