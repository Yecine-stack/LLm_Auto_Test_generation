package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class US005Test {

@Test
    public void US005_createHabitWithEmptyNameThrowsException() {
        HabitManager habitManager = new HabitManager();
        assertThrows(IllegalArgumentException.class, () -> {
            habitManager.createHabit("", "Category", HabitFrequency.DAILY, "Description");
        });
    }

    @Test
    public void US005_createHabitWithValidNameSucceeds() {
        HabitManager habitManager = new HabitManager();
        habitManager.createHabit("Exercise", "Fitness", HabitFrequency.DAILY, "Go for a run");
        assertTrue(habitManager.getHabit("Exercise") != null);
    }

    @Test
    public void US005_editHabitWithEmptyNameThrowsException() {
        HabitManager habitManager = new HabitManager();
        habitManager.createHabit("Exercise", "Fitness", HabitFrequency.DAILY, "Go for a run");
        assertThrows(IllegalArgumentException.class, () -> {
            habitManager.editHabit("Exercise", "", "Category", HabitFrequency.DAILY, "Description");
        });
    }

    @Test
    public void US005_editHabitWithValidNameSucceeds() {
        HabitManager habitManager = new HabitManager();
        habitManager.createHabit("Exercise", "Fitness", HabitFrequency.DAILY, "Go for a run");
        habitManager.editHabit("Exercise", "Exercise", "Category", HabitFrequency.DAILY, "Go for a run");
        assertTrue(habitManager.getHabit("Exercise") != null);
    }

    @Test
    public void US005_deleteHabitSucceeds() {
        HabitManager habitManager = new HabitManager();
        habitManager.createHabit("Exercise", "Fitness", HabitFrequency.DAILY, "Go for a run");
        habitManager.deleteHabit("Exercise");
        assertNull(habitManager.getHabit("Exercise"));
    }

}
