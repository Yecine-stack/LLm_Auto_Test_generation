package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US019Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US019_EnsurePastRecordsRemainAvailableAfterEditingDescription() {
        // Create a habit
        habitTracker.createHabit("Drink Water", "Daily");

        // Mark the habit as completed
        habitTracker.markHabitCompleted("Drink Water");

        // Edit the habit description
        habitTracker.editHabitDescription("Drink Water", "Drink plenty of water");

        // Verify that the completion record is still available
        assertTrue(habitTracker.isHabitCompletedToday("Drink Water"));
    }

    @Test
    public void US019_EnsurePastRecordsRemainAvailableAfterEditingCategory() {
        // Create a habit
        habitTracker.createHabit("Drink Water", "Daily");

        // Mark the habit as completed
        habitTracker.markHabitCompleted("Drink Water");

        // Edit the habit category
        habitTracker.editHabitCategory("Drink Water", "Health");

        // Verify that the completion record is still available
        assertTrue(habitTracker.isHabitCompletedToday("Drink Water"));
    }

    @Test
    public void US019_EnsurePastRecordsRemainAvailableAfterDeletingAndRecreatingHabit() {
        // Create a habit
        habitTracker.createHabit("Drink Water", "Daily");

        // Mark the habit as completed
        habitTracker.markHabitCompleted("Drink Water");

        // Delete the habit
        habitTracker.deleteHabit("Drink Water");

        // Recreate the habit
        habitTracker.createHabit("Drink Water", "Daily");

        // Verify that the completion record is still available
        assertTrue(habitTracker.isHabitCompletedToday("Drink Water"));
    }

    @Test
    public void US019_EnsurePastRecordsRemainAvailableAfterEditingAndRecreatingHabit() {
        // Create a habit
        habitTracker.createHabit("Drink Water", "Daily");

        // Mark the habit as completed
        habitTracker.markHabitCompleted("Drink Water");

        // Edit the habit
        habitTracker.editHabit("Drink Water", "Drink plenty of water", "Health");

        // Verify that the completion record is still available
        assertTrue(habitTracker.isHabitCompletedToday("Drink Water"));
    }

}
