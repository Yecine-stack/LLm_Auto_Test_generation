package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US001Test {

private HabitManager habitManager;

    @BeforeEach
    public void setUp() {
        habitManager = new HabitManager();
    }

    @Test
    public void US001_CreateHabit_Success() {
        // Arrange
        String habitName = "Drink Water";
        String category = "Health";
        HabitFrequency frequency = HabitFrequency.DAILY;

        // Act
        habitManager.createHabit(habitName, category, frequency, null);

        // Assert
        assertTrue(habitManager.getHabitByName(habitName) != null);
    }

    @Test
    public void US001_CreateHabit_WithDescription_Success() {
        // Arrange
        String habitName = "Drink Water";
        String category = "Health";
        HabitFrequency frequency = HabitFrequency.DAILY;
        String description = "Drink at least 8 glasses of water per day.";

        // Act
        habitManager.createHabit(habitName, category, frequency, description);

        // Assert
        Habit habit = habitManager.getHabitByName(habitName);
        assertEquals(description, habit.getDescription());
    }

    @Test
    public void US001_CreateHabit_EmptyName_Failure() {
        // Arrange
        String habitName = "";
        String category = "Health";
        HabitFrequency frequency = HabitFrequency.DAILY;

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            habitManager.createHabit(habitName, category, frequency, null);
        });
    }

    @Test
    public void US001_CreateHabit_DuplicateName_Failure() {
        // Arrange
        String habitName = "Drink Water";
        String category = "Health";
        HabitFrequency frequency = HabitFrequency.DAILY;
        habitManager.createHabit(habitName, category, frequency, null);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            habitManager.createHabit(habitName, category, frequency, null);
        });
    }

}
