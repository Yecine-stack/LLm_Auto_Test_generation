package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US025Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US025_RecoverPreviouslySavedData() {
        // Simulate saving data
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Drink 8 glasses of water daily");
        habitTracker.markHabitCompleted("Drink Water");
        habitTracker.saveData();

        // Simulate application restart
        habitTracker = new HabitTracker();

        // Verify data is recovered
        assertTrue(habitTracker.getHabit("Drink Water") != null);
        assertTrue(habitTracker.isHabitCompleted("Drink Water"));
    }

    @Test
    public void US025_RecoverEmptyData() {
        // Simulate application restart with no saved data
        habitTracker = new HabitTracker();

        // Verify no data is recovered
        assertNull(habitTracker.getHabit("Drink Water"));
        assertFalse(habitTracker.isHabitCompleted("Drink Water"));
    }

    @Test
    public void US025_RecoverDataWithInvalidHabitName() {
        // Simulate saving data with an invalid habit name
        habitTracker.createHabit("", "Health", "Daily", "Drink 8 glasses of water daily");
        habitTracker.saveData();

        // Simulate application restart
        habitTracker = new HabitTracker();

        // Verify no data is recovered
        assertNull(habitTracker.getHabit(""));
    }

    @Test
    public void US025_RecoverDataWithDuplicateHabitName() {
        // Simulate saving data with a duplicate habit name
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Drink 8 glasses of water daily");
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Drink 8 glasses of water daily");
        habitTracker.saveData();

        // Simulate application restart
        habitTracker = new HabitTracker();

        // Verify only one habit is recovered
        assertEquals(1, habitTracker.getAllHabits().size());
    }

}
