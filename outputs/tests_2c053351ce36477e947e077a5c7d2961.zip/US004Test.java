package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US004Test {

private HabitManager habitManager;

    @BeforeEach
    public void setUp() {
        habitManager = new HabitManager();
    }

    @Test
    public void US004_CreateHabitWithDuplicateName() {
        // Arrange
        Habit habit1 = new Habit("Exercise");
        habitManager.addHabit(habit1);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            Habit habit2 = new Habit("Exercise");
            habitManager.addHabit(habit2);
        });
    }

    @Test
    public void US004_CreateHabitWithEmptyName() {
        // Arrange
        Habit habit = new Habit("");

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            habitManager.addHabit(habit);
        });
    }

    @Test
    public void US004_CreateValidHabit() {
        // Arrange
        Habit habit = new Habit("Exercise");

        // Act
        habitManager.addHabit(habit);

        // Assert
        assertTrue(habitManager.getHabits().contains(habit));
    }

}
