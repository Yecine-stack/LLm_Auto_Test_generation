package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US022Test {

private NotificationService notificationService;

    @BeforeEach
    public void setUp() {
        notificationService = new NotificationService();
    }

    @Test
    public void US022_DisplayNotificationIfRemindersEnabled() {
        // Arrange
        boolean remindersEnabled = true;

        // Act
        notificationService.setRemindersEnabled(remindersEnabled);
        boolean notificationDisplayed = notificationService.displayNotification();

        // Assert
        assertTrue(notificationDisplayed, "Notification should be displayed if reminders are enabled");
    }

    @Test
    public void US022_NotDisplayNotificationIfRemindersDisabled() {
        // Arrange
        boolean remindersEnabled = false;

        // Act
        notificationService.setRemindersEnabled(remindersEnabled);
        boolean notificationDisplayed = notificationService.displayNotification();

        // Assert
        assertFalse(notificationDisplayed, "Notification should not be displayed if reminders are disabled");
    }

    @Test
    public void US022_DisplayNotificationAfterEnablingReminders() {
        // Arrange
        boolean remindersEnabled = false;
        notificationService.setRemindersEnabled(remindersEnabled);

        // Act
        remindersEnabled = true;
        notificationService.setRemindersEnabled(remindersEnabled);
        boolean notificationDisplayed = notificationService.displayNotification();

        // Assert
        assertTrue(notificationDisplayed, "Notification should be displayed after enabling reminders");
    }

    @Test
    public void US022_NotDisplayNotificationAfterDisablingReminders() {
        // Arrange
        boolean remindersEnabled = true;
        notificationService.setRemindersEnabled(remindersEnabled);

        // Act
        remindersEnabled = false;
        notificationService.setRemindersEnabled(remindersEnabled);
        boolean notificationDisplayed = notificationService.displayNotification();

        // Assert
        assertFalse(notificationDisplayed, "Notification should not be displayed after disabling reminders");
    }

}
