package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US027Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US027_CreateHabit_Success() {
        habitTracker.createHabit("Drink Water", "Daily");
        assertTrue(habitTracker.getHabit("Drink Water") != null);
    }

    @Test
    public void US027_CreateHabit_DuplicateName_Failure() {
        habitTracker.createHabit("Drink Water", "Daily");
        assertThrows(IllegalArgumentException.class, () -> habitTracker.createHabit("Drink Water", "Daily"));
    }

    @Test
    public void US027_CreateHabit_EmptyName_Failure() {
        assertThrows(IllegalArgumentException.class, () -> habitTracker.createHabit("", "Daily"));
    }

    @Test
    public void US027_EditHabit_Success() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.editHabit("Drink Water", "Drink Water Daily", "Daily");
        assertEquals("Drink Water Daily", habitTracker.getHabit("Drink Water").getDescription());
    }

    @Test
    public void US027_EditHabit_ChangeName_Success() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.editHabit("Drink Water", "Drink Water Daily", "Daily");
        assertTrue(habitTracker.getHabit("Drink Water Daily") != null);
        assertNull(habitTracker.getHabit("Drink Water"));
    }

    @Test
    public void US027_DeleteHabit_Success() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.deleteHabit("Drink Water");
        assertNull(habitTracker.getHabit("Drink Water"));
    }

    @Test
    public void US027_MarkHabitCompleted_Success() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        assertTrue(habitTracker.getHabit("Drink Water").isCompletedToday());
    }

    @Test
    public void US027_MarkHabitCompleted_MultipleTimes_Failure() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        habitTracker.markHabitCompleted("Drink Water");
        assertFalse(habitTracker.getHabit("Drink Water").isCompletedToday());
    }

    @Test
    public void US027_MarkHabitCompleted_Undo_Success() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        habitTracker.undoHabitCompletion("Drink Water");
        assertFalse(habitTracker.getHabit("Drink Water").isCompletedToday());
    }

    @Test
    public void US027_ViewCalendarHistory_Success() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        assertTrue(habitTracker.getCalendarHistory().containsKey("Drink Water"));
    }

    @Test
    public void US027_ViewCalendarHistory_OldRecords_Failure() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        habitTracker.markHabitCompleted("Drink Water");
        habitTracker.undoHabitCompletion("Drink Water");
        habitTracker.undoHabitCompletion("Drink Water");
        assertFalse(habitTracker.getCalendarHistory().containsKey("Drink Water"));
    }

    @Test
    public void US027_ConfigureReminder_Success() {
        habitTracker.setReminderTime(12, 0);
        assertEquals(12, habitTracker.getReminderTime().getHour());
        assertEquals(0, habitTracker.getReminderTime().getMinute());
    }

    @Test
    public void US027_ConfigureReminder_ChangeTime_Success() {
        habitTracker.setReminderTime(12, 0);
        habitTracker.setReminderTime(14, 0);
        assertEquals(14, habitTracker.getReminderTime().getHour());
        assertEquals(0, habitTracker.getReminderTime().getMinute());
    }

    @Test
    public void US027_ViewDashboard_Success() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        assertTrue(habitTracker.getDashboard().getTotalActiveHabits() == 1);
        assertTrue(habitTracker.getDashboard().getHabitsCompletedToday() == 1);
        assertTrue(habitTracker.getDashboard().getHabitsMissedToday() == 0);
    }

    @Test
    public void US027_ViewStatistics_Success() {
        habitTracker.createHabit("Drink Water", "Daily");
        habitTracker.markHabitCompleted("Drink Water");
        assertTrue(habitTracker.getStatistics().getTotalCompletions() == 1);
        assertTrue(habitTracker.getStatistics().getCompletionRate() == 100.0);
    }

}
