package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US018Test {

private CalendarHistory calendarHistory;

    @BeforeEach
    public void setUp() {
        calendarHistory = new CalendarHistory();
    }

    @Test
    public void US018_ViewCalendarForNewHabit() {
        // Create a new habit
        Habit habit = new Habit("Drink Water", "Health", Frequency.DAILY);

        // Mark the habit as completed
        calendarHistory.markHabitCompleted(habit);

        // Verify the calendar shows the habit as completed
        assertTrue(calendarHistory.isHabitCompleted(habit, LocalDate.now()));
    }

    @Test
    public void US018_ViewCalendarForExistingHabit() {
        // Create a new habit
        Habit habit = new Habit("Exercise", "Fitness", Frequency.WEEKLY);

        // Mark the habit as completed
        calendarHistory.markHabitCompleted(habit);

        // Verify the calendar shows the habit as completed
        assertTrue(calendarHistory.isHabitCompleted(habit, LocalDate.now()));
    }

    @Test
    public void US018_ViewCalendarForMissedHabit() {
        // Create a new habit
        Habit habit = new Habit("Read Book", "Personal Development", Frequency.DAILY);

        // Verify the calendar shows the habit as missed
        assertFalse(calendarHistory.isHabitCompleted(habit, LocalDate.now()));
    }

    @Test
    public void US018_ViewCalendarForPastHabit() {
        // Create a new habit
        Habit habit = new Habit("Meditate", "Mindfulness", Frequency.WEEKLY);

        // Mark the habit as completed
        calendarHistory.markHabitCompleted(habit, LocalDate.now().minusDays(1));

        // Verify the calendar shows the habit as completed
        assertTrue(calendarHistory.isHabitCompleted(habit, LocalDate.now().minusDays(1)));
    }

    @Test
    public void US018_ViewCalendarForFutureHabit() {
        // Create a new habit
        Habit habit = new Habit("Yoga", "Wellness", Frequency.DAILY);

        // Verify the calendar shows the habit as missed
        assertFalse(calendarHistory.isHabitCompleted(habit, LocalDate.now().plusDays(1)));
    }

    @Test
    public void US018_ViewCalendarForMultipleHabits() {
        // Create multiple habits
        Habit habit1 = new Habit("Drink Water", "Health", Frequency.DAILY);
        Habit habit2 = new Habit("Exercise", "Fitness", Frequency.WEEKLY);

        // Mark habits as completed
        calendarHistory.markHabitCompleted(habit1);
        calendarHistory.markHabitCompleted(habit2);

        // Verify the calendar shows the habits as completed
        assertTrue(calendarHistory.isHabitCompleted(habit1, LocalDate.now()));
        assertTrue(calendarHistory.isHabitCompleted(habit2, LocalDate.now()));
    }

    @Test
    public void US018_ViewCalendarForInvalidHabit() {
        // Create an invalid habit
        Habit habit = new Habit("", "Health", Frequency.DAILY);

        // Verify the calendar shows the habit as missed
        assertFalse(calendarHistory.isHabitCompleted(habit, LocalDate.now()));
    }

    @Test
    public void US018_ViewCalendarForDeletedHabit() {
        // Create a new habit
        Habit habit = new Habit("Drink Water", "Health", Frequency.DAILY);

        // Mark the habit as completed
        calendarHistory.markHabitCompleted(habit);

        // Delete the habit
        calendarHistory.deleteHabit(habit);

        // Verify the calendar shows the habit as missed
        assertFalse(calendarHistory.isHabitCompleted(habit, LocalDate.now()));
    }

}
