package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;

public class US014Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US014_DisplayHabitsCompletedToday_NoHabitsCompleted() {
        // Given
        // No habits are completed today

        // When
        int habitsCompletedToday = habitTracker.getHabitsCompletedToday();

        // Then
        assertEquals(0, habitsCompletedToday);
    }

    @Test
    public void US014_DisplayHabitsCompletedToday_OneHabitCompletedToday() {
        // Given
        habitTracker.completeHabit("Exercise");
        habitTracker.completeHabit("Read");

        // When
        int habitsCompletedToday = habitTracker.getHabitsCompletedToday();

        // Then
        assertEquals(2, habitsCompletedToday);
    }

    @Test
    public void US014_DisplayHabitsCompletedToday_HabitCompletedYesterday() {
        // Given
        habitTracker.completeHabit("Exercise");
        habitTracker.completeHabit("Read");
        habitTracker.undoCompletion("Exercise");

        // When
        int habitsCompletedToday = habitTracker.getHabitsCompletedToday();

        // Then
        assertEquals(1, habitsCompletedToday);
    }

    @Test
    public void US014_DisplayHabitsCompletedToday_HabitCompletedMultipleTimesToday() {
        // Given
        habitTracker.completeHabit("Exercise");
        habitTracker.completeHabit("Read");
        habitTracker.completeHabit("Exercise");

        // When
        int habitsCompletedToday = habitTracker.getHabitsCompletedToday();

        // Then
        assertEquals(2, habitsCompletedToday);
    }

}
