package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US024Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US024_CreateHabit_Success() {
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Stay hydrated");
        assertTrue(habitTracker.getHabit("Drink Water") != null);
    }

    @Test
    public void US024_CreateHabit_DuplicateName_Failure() {
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Stay hydrated");
        assertThrows(IllegalArgumentException.class, () -> habitTracker.createHabit("Drink Water", "Health", "Daily", "Stay hydrated"));
    }

    @Test
    public void US024_CreateHabit_EmptyName_Failure() {
        assertThrows(IllegalArgumentException.class, () -> habitTracker.createHabit("", "Health", "Daily", "Stay hydrated"));
    }

    @Test
    public void US024_CompleteHabit_Success() {
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Stay hydrated");
        habitTracker.completeHabit("Drink Water");
        assertTrue(habitTracker.getHabit("Drink Water").isCompletedToday());
    }

    @Test
    public void US024_CompleteHabit_MultipleTimes_Failure() {
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Stay hydrated");
        habitTracker.completeHabit("Drink Water");
        assertThrows(IllegalStateException.class, () -> habitTracker.completeHabit("Drink Water"));
    }

    @Test
    public void US024_CompleteHabit_Undo_Success() {
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Stay hydrated");
        habitTracker.completeHabit("Drink Water");
        habitTracker.undoCompletion("Drink Water");
        assertFalse(habitTracker.getHabit("Drink Water").isCompletedToday());
    }

    @Test
    public void US024_CompleteHabit_Undo_MultipleTimes_Failure() {
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Stay hydrated");
        habitTracker.completeHabit("Drink Water");
        habitTracker.undoCompletion("Drink Water");
        assertThrows(IllegalStateException.class, () -> habitTracker.undoCompletion("Drink Water"));
    }

    @Test
    public void US024_CompleteHabit_OldRecord_Failure() {
        habitTracker.createHabit("Drink Water", "Health", "Daily", "Stay hydrated");
        habitTracker.completeHabit("Drink Water");
        habitTracker.undoCompletion("Drink Water");
        habitTracker.completeHabit("Drink Water");
        assertThrows(IllegalStateException.class, () -> habitTracker.completeHabit("Drink Water"));
    }

}
