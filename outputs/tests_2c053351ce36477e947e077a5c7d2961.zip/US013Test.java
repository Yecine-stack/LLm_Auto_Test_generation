package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;

public class US013Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US013_DisplayTotalActiveHabits_InitialCountIsZero() {
        assertEquals(0, habitTracker.getTotalActiveHabits());
    }

    @Test
    public void US013_DisplayTotalActiveHabits_IncreasesAfterCreatingHabit() {
        habitTracker.createHabit("Drink Water", "Hydration", HabitFrequency.DAILY);
        assertEquals(1, habitTracker.getTotalActiveHabits());
    }

    @Test
    public void US013_DisplayTotalActiveHabits_DecreasesAfterDeletingHabit() {
        habitTracker.createHabit("Drink Water", "Hydration", HabitFrequency.DAILY);
        habitTracker.deleteHabit("Drink Water");
        assertEquals(0, habitTracker.getTotalActiveHabits());
    }

    @Test
    public void US013_DisplayTotalActiveHabits_IgnoresInactiveHabits() {
        habitTracker.createHabit("Drink Water", "Hydration", HabitFrequency.DAILY);
        habitTracker.markHabitAsCompleted("Drink Water");
        habitTracker.deleteHabit("Drink Water");
        assertEquals(0, habitTracker.getTotalActiveHabits());
    }

    @Test
    public void US013_DisplayTotalActiveHabits_UpdatesAfterEditingHabit() {
        habitTracker.createHabit("Drink Water", "Hydration", HabitFrequency.DAILY);
        habitTracker.editHabit("Drink Water", "Drink Water", "Hydration", HabitFrequency.WEEKLY);
        assertEquals(1, habitTracker.getTotalActiveHabits());
    }

}
