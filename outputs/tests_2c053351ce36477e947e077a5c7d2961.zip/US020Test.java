package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class US020Test {

@Test
    public void US020_ShouldPreventEditingOfHistoricalRecords() {
        // Arrange
        HabitTracker habitTracker = new HabitTracker();
        habitTracker.createHabit("Drink Water", "Health", HabitFrequency.DAILY);
        habitTracker.markHabitCompleted("Drink Water");
        habitTracker.advanceDay();
        habitTracker.markHabitCompleted("Drink Water");

        // Act & Assert
        assertThrows(UnsupportedOperationException.class, () -> {
            habitTracker.editHabitDescription("Drink Water", "Drink more water");
        });
    }

    @Test
    public void US020_ShouldAllowEditingOfRecentRecords() {
        // Arrange
        HabitTracker habitTracker = new HabitTracker();
        habitTracker.createHabit("Drink Water", "Health", HabitFrequency.DAILY);
        habitTracker.markHabitCompleted("Drink Water");
        habitTracker.advanceDay();

        // Act & Assert
        assertDoesNotThrow(() -> {
            habitTracker.editHabitDescription("Drink Water", "Drink more water");
        });
    }

    @Test
    public void US020_ShouldPreventEditingOfRecordsOlderThanSevenDays() {
        // Arrange
        HabitTracker habitTracker = new HabitTracker();
        habitTracker.createHabit("Drink Water", "Health", HabitFrequency.DAILY);
        habitTracker.markHabitCompleted("Drink Water");
        habitTracker.advanceDay();
        habitTracker.advanceDay();
        habitTracker.advanceDay();
        habitTracker.advanceDay();
        habitTracker.advanceDay();
        habitTracker.advanceDay();

        // Act & Assert
        assertThrows(UnsupportedOperationException.class, () -> {
            habitTracker.editHabitDescription("Drink Water", "Drink more water");
        });
    }

}
