package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US021Test {

private NotificationService notificationService;

    @BeforeEach
    public void setUp() {
        notificationService = new NotificationService();
    }

    @Test
    public void US021_configureReminderTime_validTime() {
        // Arrange
        LocalTime validTime = LocalTime.of(8, 0);

        // Act
        notificationService.configureReminderTime(validTime);

        // Assert
        assertEquals(validTime, notificationService.getReminderTime());
    }

    @Test
    public void US021_configureReminderTime_invalidTime() {
        // Arrange
        LocalTime invalidTime = LocalTime.of(25, 0);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            notificationService.configureReminderTime(invalidTime);
        });
    }

    @Test
    public void US021_configureReminderTime_nullTime() {
        // Arrange

        // Act & Assert
        assertThrows(NullPointerException.class, () -> {
            notificationService.configureReminderTime(null);
        });
    }

    @Test
    public void US021_configureReminderTime_emptyTime() {
        // Arrange
        LocalTime emptyTime = LocalTime.of(0, 0);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            notificationService.configureReminderTime(emptyTime);
        });
    }

    @Test
    public void US021_configureReminderTime_sameTime() {
        // Arrange
        LocalTime time = LocalTime.of(12, 0);
        notificationService.configureReminderTime(time);

        // Act
        notificationService.configureReminderTime(time);

        // Assert
        assertEquals(time, notificationService.getReminderTime());
    }

}
