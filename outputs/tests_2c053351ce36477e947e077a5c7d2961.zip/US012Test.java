package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US012Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US012_CalculateCompletionRate_NoHabits() {
        // Arrange
        // No habits added

        // Act
        double completionRate = habitTracker.calculateCompletionRate();

        // Assert
        assertEquals(0.0, completionRate);
    }

    @Test
    public void US012_CalculateCompletionRate_OneHabitCompleted() {
        // Arrange
        habitTracker.createHabit("Exercise", "Daily", null);
        habitTracker.markHabitCompleted("Exercise");

        // Act
        double completionRate = habitTracker.calculateCompletionRate();

        // Assert
        assertEquals(1.0, completionRate);
    }

    @Test
    public void US012_CalculateCompletionRate_OneHabitMissed() {
        // Arrange
        habitTracker.createHabit("Exercise", "Daily", null);
        // No completion recorded

        // Act
        double completionRate = habitTracker.calculateCompletionRate();

        // Assert
        assertEquals(0.0, completionRate);
    }

    @Test
    public void US012_CalculateCompletionRate_MultipleHabits() {
        // Arrange
        habitTracker.createHabit("Exercise", "Daily", null);
        habitTracker.createHabit("Read", "Daily", null);
        habitTracker.markHabitCompleted("Exercise");
        habitTracker.markHabitCompleted("Read");

        // Act
        double completionRate = habitTracker.calculateCompletionRate();

        // Assert
        assertEquals(1.0, completionRate);
    }

    @Test
    public void US012_CalculateCompletionRate_MultipleHabits_Missed() {
        // Arrange
        habitTracker.createHabit("Exercise", "Daily", null);
        habitTracker.createHabit("Read", "Daily", null);
        habitTracker.markHabitCompleted("Exercise");
        // No completion recorded for "Read"

        // Act
        double completionRate = habitTracker.calculateCompletionRate();

        // Assert
        assertEquals(0.5, completionRate);
    }

    @Test
    public void US012_CalculateCompletionRate_MultipleHabits_Mixed() {
        // Arrange
        habitTracker.createHabit("Exercise", "Daily", null);
        habitTracker.createHabit("Read", "Daily", null);
        habitTracker.markHabitCompleted("Exercise");
        habitTracker.markHabitCompleted("Read");
        habitTracker.markHabitCompleted("Exercise");

        // Act
        double completionRate = habitTracker.calculateCompletionRate();

        // Assert
        assertEquals(0.6666666666666666, completionRate);
    }

}
