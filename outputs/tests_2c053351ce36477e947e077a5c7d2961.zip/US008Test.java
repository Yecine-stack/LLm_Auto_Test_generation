package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US008Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US008_CompletionDateIsAutomaticallyRecorded() {
        // Arrange
        String habitName = "Exercise";
        habitTracker.createHabit(habitName, null, HabitFrequency.DAILY, null);

        // Act
        habitTracker.markHabitCompleted(habitName);

        // Assert
        assertNotNull(habitTracker.getHabit(habitName).getCompletionDate());
    }

    @Test
    public void US008_CompletionDateIsNotOverridden() {
        // Arrange
        String habitName = "Exercise";
        habitTracker.createHabit(habitName, null, HabitFrequency.DAILY, null);
        habitTracker.markHabitCompleted(habitName);

        // Act
        habitTracker.markHabitCompleted(habitName);

        // Assert
        assertEquals(1, habitTracker.getHabit(habitName).getCompletionCount());
    }

    @Test
    public void US008_CompletionDateIsNotRecordedForNonExistentHabit() {
        // Arrange
        String nonExistentHabitName = "NonExistentHabit";

        // Act & Assert
        assertThrows(HabitNotFoundException.class, () -> {
            habitTracker.markHabitCompleted(nonExistentHabitName);
        });
    }

}
