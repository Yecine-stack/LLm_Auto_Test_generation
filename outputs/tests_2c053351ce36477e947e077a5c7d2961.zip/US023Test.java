package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US023Test {

private NotificationSettings notificationSettings;

    @BeforeEach
    public void setUp() {
        notificationSettings = new NotificationSettings();
    }

    @Test
    public void US023_ChangeReminderTime_UpdatesImmediately() {
        // Arrange
        LocalTime newReminderTime = LocalTime.of(10, 0);

        // Act
        notificationSettings.setReminderTime(newReminderTime);

        // Assert
        assertEquals(newReminderTime, notificationSettings.getReminderTime());
    }

    @Test
    public void US023_ChangeReminderTime_ToNull_ThrowsException() {
        // Arrange
        NotificationSettings notificationSettings = new NotificationSettings();
        LocalTime currentReminderTime = notificationSettings.getReminderTime();

        // Act & Assert
        assertThrows(NullPointerException.class, () -> {
            notificationSettings.setReminderTime(null);
        });

        // Verify that the reminder time remains unchanged
        assertEquals(currentReminderTime, notificationSettings.getReminderTime());
    }

    @Test
    public void US023_ChangeReminderTime_ToSameValue_NoChange() {
        // Arrange
        LocalTime currentReminderTime = notificationSettings.getReminderTime();

        // Act
        notificationSettings.setReminderTime(currentReminderTime);

        // Assert
        assertEquals(currentReminderTime, notificationSettings.getReminderTime());
    }

}
