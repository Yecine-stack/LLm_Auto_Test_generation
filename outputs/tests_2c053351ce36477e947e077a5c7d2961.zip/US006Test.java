package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US006Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US006_CompleteHabit_Success() {
        // Arrange
        String habitName = "Drink Water";
        habitTracker.createHabit(habitName, null, HabitFrequency.DAILY, null);

        // Act
        habitTracker.completeHabit(habitName);

        // Assert
        assertTrue(habitTracker.isHabitCompletedToday(habitName));
    }

    @Test
    public void US006_CompleteHabit_MultipleTimes_Failure() {
        // Arrange
        String habitName = "Drink Water";
        habitTracker.createHabit(habitName, null, HabitFrequency.DAILY, null);

        // Act
        habitTracker.completeHabit(habitName);
        boolean result = habitTracker.completeHabit(habitName);

        // Assert
        assertFalse(result);
    }

    @Test
    public void US006_CompleteHabit_InvalidHabitName_Failure() {
        // Arrange
        String habitName = "Drink Water";
        habitTracker.createHabit(habitName, null, HabitFrequency.DAILY, null);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> habitTracker.completeHabit("Invalid Habit"));
    }

    @Test
    public void US006_CompleteHabit_WithReminder_Success() {
        // Arrange
        String habitName = "Drink Water";
        habitTracker.createHabit(habitName, null, HabitFrequency.DAILY, null);
        habitTracker.setReminderTime(LocalTime.NOON);

        // Act
        habitTracker.completeHabit(habitName);

        // Assert
        assertTrue(habitTracker.isHabitCompletedToday(habitName));
    }

    @Test
    public void US006_CompleteHabit_WithReminder_InvalidTime_Failure() {
        // Arrange
        String habitName = "Drink Water";
        habitTracker.createHabit(habitName, null, HabitFrequency.DAILY, null);
        habitTracker.setReminderTime(LocalTime.NOON);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> habitTracker.completeHabit("Invalid Habit"));
    }

}
