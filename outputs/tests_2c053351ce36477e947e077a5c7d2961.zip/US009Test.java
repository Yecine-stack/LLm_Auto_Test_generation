package generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class US009Test {

private HabitTracker habitTracker;

    @BeforeEach
    public void setUp() {
        habitTracker = new HabitTracker();
    }

    @Test
    public void US009_CalculateCurrentStreak_NoHabits_CompletedStreakIsZero() {
        assertEquals(0, habitTracker.calculateCurrentStreak());
    }

    @Test
    public void US009_CalculateCurrentStreak_OneHabitNotCompleted_CompletedStreakIsZero() {
        habitTracker.createHabit("Exercise", "daily");
        assertEquals(0, habitTracker.calculateCurrentStreak());
    }

    @Test
    public void US009_CalculateCurrentStreak_OneHabitCompletedToday_CompletedStreakIsOne() {
        habitTracker.createHabit("Exercise", "daily");
        habitTracker.markHabitAsCompleted("Exercise");
        assertEquals(1, habitTracker.calculateCurrentStreak());
    }

    @Test
    public void US009_CalculateCurrentStreak_MultipleHabitsCompletedToday_CompletedStreakIsOne() {
        habitTracker.createHabit("Exercise", "daily");
        habitTracker.createHabit("Read", "daily");
        habitTracker.markHabitAsCompleted("Exercise");
        habitTracker.markHabitAsCompleted("Read");
        assertEquals(1, habitTracker.calculateCurrentStreak());
    }

    @Test
    public void US009_CalculateCurrentStreak_OneHabitCompletedYesterday_CompletedStreakIsZero() {
        habitTracker.createHabit("Exercise", "daily");
        habitTracker.markHabitAsCompleted("Exercise");
        habitTracker.advanceDay();
        assertEquals(0, habitTracker.calculateCurrentStreak());
    }

    @Test
    public void US009_CalculateCurrentStreak_MultipleHabitsCompletedYesterday_CompletedStreakIsZero() {
        habitTracker.createHabit("Exercise", "daily");
        habitTracker.createHabit("Read", "daily");
        habitTracker.markHabitAsCompleted("Exercise");
        habitTracker.markHabitAsCompleted("Read");
        habitTracker.advanceDay();
        assertEquals(0, habitTracker.calculateCurrentStreak());
    }

    @Test
    public void US009_CalculateCurrentStreak_OneHabitCompletedYesterdayAndToday_CompletedStreakIsOne() {
        habitTracker.createHabit("Exercise", "daily");
        habitTracker.markHabitAsCompleted("Exercise");
        habitTracker.advanceDay();
        habitTracker.markHabitAsCompleted("Exercise");
        assertEquals(1, habitTracker.calculateCurrentStreak());
    }

    @Test
    public void US009_CalculateCurrentStreak_MultipleHabitsCompletedYesterdayAndToday_CompletedStreakIsOne() {
        habitTracker.createHabit("Exercise", "daily");
        habitTracker.createHabit("Read", "daily");
        habitTracker.markHabitAsCompleted("Exercise");
        habitTracker.markHabitAsCompleted("Read");
        habitTracker.advanceDay();
        habitTracker.markHabitAsCompleted("Exercise");
        habitTracker.markHabitAsCompleted("Read");
        assertEquals(1, habitTracker.calculateCurrentStreak());
    }

    @Test
    public void US009_CalculateCurrentStreak_OneHabitCompletedYesterdayAndSkippedToday_CompletedStreakIsZero() {
        habitTracker.createHabit("Exercise", "daily");
        habitTracker.markHabitAsCompleted("Exercise");
        habitTracker.advanceDay();
        habitTracker.advanceDay();
        habitTracker.markHabitAsCompleted("Exercise");
        assertEquals(0, habitTracker.calculateCurrentStreak());
    }

    @Test
    public void US009_CalculateCurrentStreak_MultipleHabitsCompletedYesterdayAndSkippedToday_CompletedStreakIsZero() {
        habitTracker.createHabit("Exercise", "daily");
        habitTracker.createHabit("Read", "daily");
        habitTracker.markHabitAsCompleted("Exercise");
        habitTracker.markHabitAsCompleted("Read");
        habitTracker.advanceDay();
        habitTracker.advanceDay();
        habitTracker.markHabitAsCompleted("Exercise");
        habitTracker.markHabitAsCompleted("Read");
        assertEquals(0, habitTracker.calculateCurrentStreak());
    }

}
